Author - Knightcoders
Member- Kuldeep Suhag
	Hyesoo Kim
	Vadiraj Kulkarni
	Teenu Thomas Thaliath


How to run server
-----------------------------
command - java -jar ActivityStreamerServer.jar -lh <host address> -lp <portno>

How to run client
-----------------------------
command - java -jar ActivityStreamerClient.jar -rh <remote host address> -rh <remote port no> -u <Username>