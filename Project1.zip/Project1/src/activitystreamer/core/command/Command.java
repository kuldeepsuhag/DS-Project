package activitystreamer.core.command;

public interface Command {
}
