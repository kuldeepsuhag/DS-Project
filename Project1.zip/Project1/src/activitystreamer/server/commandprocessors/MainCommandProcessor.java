package activitystreamer.server.commandprocessors;

import activitystreamer.core.command.Command;
import activitystreamer.core.command.InvalidMessageCommand;
import activitystreamer.core.commandprocessor.CommandProcessor;
import activitystreamer.core.shared.Connection;
import activitystreamer.server.commandhandlers.*;
import activitystreamer.server.services.contracts.*;
import com.google.inject.Inject;

public class MainCommandProcessor extends CommandProcessor {
    private final ConnectionManager connectionManager;

    @Inject
    public MainCommandProcessor(ServerAuthService serverAuthService, UserAuthService userAuthService,
                                ConnectionManager connectionManager, BroadcastService broadcastService,
                                RemoteServerStateService remoteServerStateService) {
        super();
        this.connectionManager = connectionManager;
        handlers.add(new ActivityBroadcastCommandHandler(serverAuthService, broadcastService, connectionManager));
        handlers.add(new ActivityMessageCommandHandler(userAuthService, broadcastService, connectionManager));
        handlers.add(new AuthenticateCommandHandler(userAuthService, serverAuthService, connectionManager));
        handlers.add(new AuthenticationFailCommandHandler(serverAuthService, connectionManager));
        handlers.add(new LockAllowedCommandHandler(userAuthService, serverAuthService, broadcastService, connectionManager));
        handlers.add(new LockDeniedCommandHandler(userAuthService, serverAuthService, broadcastService, connectionManager));
        handlers.add(new LockRequestCommandHandler(userAuthService, serverAuthService, connectionManager));
        handlers.add(new LoginCommandHandler(userAuthService, serverAuthService, remoteServerStateService, connectionManager));
        handlers.add(new RegisterCommandHandler(userAuthService, serverAuthService, connectionManager));
        handlers.add(new ServerAnnounceCommandHandler(remoteServerStateService, broadcastService, serverAuthService, connectionManager));
        handlers.add(new LogoutCommandHandler(userAuthService, connectionManager));
    }

    @Override
    public void invalidMessage(Connection connection, Command command) {
        Command invalidCommand = new InvalidMessageCommand("Command type is invalid.");
        connection.pushCommand(invalidCommand);
        connectionManager.closeConnection(connection);
    }
}
